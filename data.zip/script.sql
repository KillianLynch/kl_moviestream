
@/home/oracle/Downloads/MovieStream_DDL.sql
@/home/oracle/Downloads/genre.sql
@/home/oracle/Downloads/cust_segment.sql
@/home/oracle/Downloads/cust.sql
@/home/oracle/Downloads/movie.sql
@/home/oracle/Downloads/custsales.sql
